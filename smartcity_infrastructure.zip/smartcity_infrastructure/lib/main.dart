import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import 'screens/auth/auth_gate.dart';
import 'screens/welcome_screen.dart';
import 'theme/app_colors.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  await Supabase.initialize(
    url:
    'https://mqdymgkgxshvkzentdmg.supabase.co',
    anonKey:
    'sb_publishable_qGdkpnvxBaOWDs2WvU2xgQ_g98Vv__D',
  );

  runApp(
    const SmartCityApp(),
  );
}

class SmartCityApp
    extends StatelessWidget {
  const SmartCityApp({
    super.key,
  });

  @override
  Widget build(
      BuildContext context,
      ) {
    final bool alreadyLoggedIn =
        Supabase.instance.client.auth
            .currentSession !=
            null;

    return MaterialApp(
      debugShowCheckedModeBanner:
      false,

      title:
      'SmartCity',

      theme:
      ThemeData(
        brightness:
        Brightness.dark,

        scaffoldBackgroundColor:
        AppColors.background,

        colorScheme:
        const ColorScheme.dark(
          primary:
          AppColors.primary,

          surface:
          AppColors.surface,
        ),
      ),

      // Persistent session:
      // If a valid Supabase session already exists, skip Welcome
      // and let AuthGate route to the correct role dashboard.
      home:
      alreadyLoggedIn
          ? const AuthGate()
          : const WelcomeScreen(),
    );
  }
}
