import 'dart:async';

import 'package:flutter/material.dart';

import '../../services/auth_service.dart';
import '../../services/login_activity_service.dart';
import '../../services/login_security_service.dart';
import '../../theme/app_colors.dart';

import 'auth_gate.dart';
import 'forgot_password_screen.dart';
import 'register_screen.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({
    super.key,
  });

  @override
  State<LoginScreen> createState() =>
      _LoginScreenState();
}

class _LoginScreenState
    extends State<LoginScreen> {
  final AuthService authService =
  AuthService();

  final LoginActivityService
  loginActivityService =
  LoginActivityService();

  final LoginSecurityService
  loginSecurityService =
  LoginSecurityService();

  final GlobalKey<FormState> formKey =
  GlobalKey<FormState>();

  final TextEditingController
  emailController =
  TextEditingController();

  final TextEditingController
  passwordController =
  TextEditingController();

  bool loading = false;

  bool hidePassword = true;

  bool blocked = false;

  DateTime? blockedUntil;

  int failedAttempts = 0;

  Timer? countdownTimer;

  @override
  void initState() {
    super.initState();

    emailController.addListener(
      _emailChanged,
    );
  }

  @override
  void dispose() {
    countdownTimer?.cancel();

    emailController
        .removeListener(
      _emailChanged,
    );

    emailController.dispose();

    passwordController.dispose();

    super.dispose();
  }

  // ============================================================
  // EMAIL CHANGED
  // ============================================================

  void _emailChanged() {
    checkLoginSecurity();
  }

  // ============================================================
  // CHECK LOGIN SECURITY
  // ============================================================

  Future<void> checkLoginSecurity() async {
    final String email =
    emailController.text.trim();

    if (email.isEmpty) {
      if (!mounted) {
        return;
      }

      setState(() {
        blocked = false;
        blockedUntil = null;
        failedAttempts = 0;
      });

      countdownTimer?.cancel();

      return;
    }

    final status =
    await loginSecurityService
        .getStatus(
      email,
    );

    if (!mounted) {
      return;
    }

    setState(() {
      blocked = status.isBlocked;

      blockedUntil =
          status.blockedUntil;

      failedAttempts =
          status.failedAttempts;
    });

    if (status.isBlocked) {
      startCountdown();
    } else {
      countdownTimer?.cancel();
    }
  }

  // ============================================================
  // BLOCK COUNTDOWN
  // ============================================================

  void startCountdown() {
    countdownTimer?.cancel();

    countdownTimer =
        Timer.periodic(
          const Duration(
            seconds: 1,
          ),
              (_) async {
            final until =
                blockedUntil;

            if (until == null) {
              return;
            }

            if (DateTime.now().isAfter(
              until,
            )) {
              countdownTimer?.cancel();

              await loginSecurityService
                  .resetAttempts(
                emailController.text,
              );

              if (!mounted) {
                return;
              }

              setState(() {
                blocked = false;
                blockedUntil = null;
                failedAttempts = 0;
              });

              return;
            }

            if (mounted) {
              setState(() {});
            }
          },
        );
  }

  // ============================================================
  // BLOCK TIME TEXT
  // ============================================================

  String get blockTimeText {
    final until =
        blockedUntil;

    if (until == null) {
      return '';
    }

    final Duration remaining =
    until.difference(
      DateTime.now(),
    );

    if (remaining.isNegative) {
      return '00:00';
    }

    final int minutes =
        remaining.inMinutes;

    final int seconds =
        remaining.inSeconds %
            60;

    return '${minutes.toString().padLeft(2, '0')}:'
        '${seconds.toString().padLeft(2, '0')}';
  }

  // ============================================================
  // EMAIL / PASSWORD LOGIN
  // ============================================================

  Future<void> login() async {
    if (loading) {
      return;
    }

    if (!(formKey.currentState
        ?.validate() ??
        false)) {
      return;
    }

    final String email =
    emailController.text
        .trim()
        .toLowerCase();

    final status =
    await loginSecurityService
        .getStatus(
      email,
    );

    if (status.isBlocked) {
      setState(() {
        blocked = true;

        blockedUntil =
            status.blockedUntil;

        failedAttempts =
            status.failedAttempts;
      });

      startCountdown();

      showMessage(
        'Too many failed login attempts. '
            'Please try again in $blockTimeText.',
      );

      return;
    }

    setState(() {
      loading = true;
    });

    try {
      final response =
      await authService.login(
        email:
        email,
        password:
        passwordController.text,
      );

      if (response.user == null) {
        throw Exception(
          'Unable to sign in.',
        );
      }

      // ========================================================
      // SUCCESS -> RESET FAILED ATTEMPTS
      // ========================================================

      await loginSecurityService
          .resetAttempts(
        email,
      );

      // ========================================================
      // LOGIN ACTIVITY
      // ========================================================

      await loginActivityService
          .recordLogin(
        loginMethod:
        'Email / Password',
      );

      if (!mounted) {
        return;
      }

      goToAuthGate();
    } catch (e) {
      // ========================================================
      // RECORD FAILED LOGIN
      // ========================================================

      final failedStatus =
      await loginSecurityService
          .recordFailedAttempt(
        email,
      );

      if (!mounted) {
        return;
      }

      setState(() {
        blocked =
            failedStatus.isBlocked;

        blockedUntil =
            failedStatus.blockedUntil;

        failedAttempts =
            failedStatus.failedAttempts;
      });

      if (failedStatus.isBlocked) {
        startCountdown();

        showMessage(
          'Too many failed login attempts. '
              'Login has been temporarily blocked for 5 minutes.',
        );
      } else {
        final int remaining =
            LoginSecurityService
                .maxFailedAttempts -
                failedStatus
                    .failedAttempts;

        showMessage(
          'Invalid email or password. '
              '$remaining attempt${remaining == 1 ? '' : 's'} remaining.',
        );
      }
    } finally {
      if (mounted) {
        setState(() {
          loading = false;
        });
      }
    }
  }

  // ============================================================
  // GOOGLE LOGIN
  // ============================================================

  Future<void> googleLogin() async {
    if (loading) {
      return;
    }

    setState(() {
      loading = true;
    });

    try {
      final response =
      await authService
          .signInWithGoogle();

      if (response.user == null) {
        throw Exception(
          'Unable to sign in with Google.',
        );
      }

      await loginActivityService
          .recordLogin(
        loginMethod:
        'Google',
      );

      if (!mounted) {
        return;
      }

      goToAuthGate();
    } catch (e) {
      if (!mounted) {
        return;
      }

      showMessage(
        e.toString().replaceFirst(
          'Exception: ',
          '',
        ),
      );
    } finally {
      if (mounted) {
        setState(() {
          loading = false;
        });
      }
    }
  }

  // ============================================================
  // AUTH GATE
  // ============================================================

  void goToAuthGate() {
    Navigator.pushAndRemoveUntil(
      context,
      MaterialPageRoute(
        builder: (_) =>
        const AuthGate(),
      ),
          (route) => false,
    );
  }

  // ============================================================
  // FORGOT PASSWORD
  // ============================================================

  void openForgotPassword() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) =>
        const ForgotPasswordScreen(),
      ),
    );
  }

  // ============================================================
  // REGISTER
  // ============================================================

  void openRegister() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) =>
        const RegisterScreen(),
      ),
    );
  }

  // ============================================================
  // MESSAGE
  // ============================================================

  void showMessage(
      String message,
      ) {
    ScaffoldMessenger.of(context)
        .hideCurrentSnackBar();

    ScaffoldMessenger.of(context)
        .showSnackBar(
      SnackBar(
        content: Text(
          message,
        ),
      ),
    );
  }

  // ============================================================
  // EMAIL VALIDATION
  // ============================================================

  String? validateEmail(
      String? value,
      ) {
    final email =
        value?.trim() ?? '';

    if (email.isEmpty) {
      return 'Email address is required.';
    }

    final RegExp emailPattern =
    RegExp(
      r'^[^@\s]+@[^@\s]+\.[^@\s]+$',
    );

    if (!emailPattern.hasMatch(
      email,
    )) {
      return 'Enter a valid email address.';
    }

    return null;
  }

  // ============================================================
  // BUILD
  // ============================================================

  @override
  Widget build(
      BuildContext context,
      ) {
    final bool loginDisabled =
        loading || blocked;

    return Scaffold(
      backgroundColor:
      AppColors.background,

      body: SafeArea(
        child: SingleChildScrollView(
          padding:
          const EdgeInsets.symmetric(
            horizontal: 24,
            vertical: 28,
          ),

          child: Form(
            key: formKey,

            child: Column(
              crossAxisAlignment:
              CrossAxisAlignment.start,

              children: [
                // =================================================
                // BACK
                // =================================================

                Container(
                  decoration:
                  BoxDecoration(
                    color:
                    AppColors.surface,

                    borderRadius:
                    BorderRadius.circular(
                      12,
                    ),

                    border:
                    Border.all(
                      color:
                      AppColors.border,
                    ),
                  ),

                  child: IconButton(
                    onPressed:
                    loading
                        ? null
                        : () {
                      Navigator.pop(
                        context,
                      );
                    },

                    icon:
                    const Icon(
                      Icons.arrow_back,

                      color:
                      AppColors
                          .textSecondary,
                    ),
                  ),
                ),

                const SizedBox(
                  height: 22,
                ),

                // =================================================
                // ICON
                // =================================================

                Container(
                  width: 58,
                  height: 58,

                  alignment:
                  Alignment.center,

                  decoration:
                  BoxDecoration(
                    color:
                    AppColors.primary
                        .withOpacity(
                      0.10,
                    ),

                    borderRadius:
                    BorderRadius.circular(
                      15,
                    ),

                    border:
                    Border.all(
                      color:
                      AppColors
                          .primaryDark,
                    ),
                  ),

                  child:
                  const Text(
                    '🔐',

                    style:
                    TextStyle(
                      fontSize: 28,
                    ),
                  ),
                ),

                const SizedBox(
                  height: 24,
                ),

                const Text(
                  'Welcome back',

                  style:
                  TextStyle(
                    fontSize: 29,

                    fontWeight:
                    FontWeight.bold,
                  ),
                ),

                const SizedBox(
                  height: 6,
                ),

                const Text(
                  'Sign in to your SmartCity account',

                  style:
                  TextStyle(
                    color:
                    AppColors
                        .textSecondary,

                    fontSize: 14,
                  ),
                ),

                const SizedBox(
                  height: 26,
                ),

                // =================================================
                // BLOCK WARNING
                // =================================================

                if (blocked) ...[
                  Container(
                    width:
                    double.infinity,

                    padding:
                    const EdgeInsets.all(
                      13,
                    ),

                    decoration:
                    BoxDecoration(
                      color:
                      AppColors.danger
                          .withOpacity(
                        0.07,
                      ),

                      borderRadius:
                      BorderRadius.circular(
                        13,
                      ),

                      border:
                      Border.all(
                        color:
                        AppColors.danger,
                      ),
                    ),

                    child: Row(
                      crossAxisAlignment:
                      CrossAxisAlignment
                          .start,

                      children: [
                        const Icon(
                          Icons.lock_clock_outlined,

                          color:
                          AppColors.danger,
                        ),

                        const SizedBox(
                          width: 10,
                        ),

                        Expanded(
                          child: Column(
                            crossAxisAlignment:
                            CrossAxisAlignment
                                .start,

                            children: [
                              const Text(
                                'Login Temporarily Blocked',

                                style:
                                TextStyle(
                                  color:
                                  AppColors
                                      .danger,

                                  fontWeight:
                                  FontWeight
                                      .bold,
                                ),
                              ),

                              const SizedBox(
                                height: 4,
                              ),

                              Text(
                                'Too many failed attempts. '
                                    'Try again in $blockTimeText.',

                                style:
                                const TextStyle(
                                  color:
                                  AppColors
                                      .textSecondary,

                                  fontSize: 10,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),

                  const SizedBox(
                    height: 20,
                  ),
                ],

                // =================================================
                // EMAIL
                // =================================================

                const _FieldLabel(
                  'EMAIL ADDRESS',
                ),

                const SizedBox(
                  height: 8,
                ),

                TextFormField(
                  controller:
                  emailController,

                  enabled:
                  !loading,

                  keyboardType:
                  TextInputType
                      .emailAddress,

                  textInputAction:
                  TextInputAction.next,

                  autofillHints:
                  const [
                    AutofillHints.email,
                  ],

                  decoration:
                  _inputDecoration(
                    hint:
                    'you@example.com',

                    prefixIcon:
                    Icons.email_outlined,
                  ),

                  validator:
                  validateEmail,
                ),

                const SizedBox(
                  height: 18,
                ),

                // =================================================
                // PASSWORD
                // =================================================

                const _FieldLabel(
                  'PASSWORD',
                ),

                const SizedBox(
                  height: 8,
                ),

                TextFormField(
                  controller:
                  passwordController,

                  enabled:
                  !loginDisabled,

                  obscureText:
                  hidePassword,

                  textInputAction:
                  TextInputAction.done,

                  autofillHints:
                  const [
                    AutofillHints.password,
                  ],

                  onFieldSubmitted:
                      (_) {
                    if (!loginDisabled) {
                      login();
                    }
                  },

                  decoration:
                  _inputDecoration(
                    hint:
                    '••••••••',

                    prefixIcon:
                    Icons.lock_outline,

                    suffix:
                    IconButton(
                      onPressed:
                          () {
                        setState(() {
                          hidePassword =
                          !hidePassword;
                        });
                      },

                      icon:
                      Icon(
                        hidePassword
                            ? Icons
                            .visibility_outlined
                            : Icons
                            .visibility_off_outlined,

                        color:
                        AppColors
                            .textSecondary,
                      ),
                    ),
                  ),

                  validator:
                      (value) {
                    if (value == null ||
                        value.isEmpty) {
                      return 'Password is required.';
                    }

                    return null;
                  },
                ),

                // =================================================
                // ATTEMPT INDICATOR
                // =================================================

                if (!blocked &&
                    failedAttempts > 0) ...[
                  const SizedBox(
                    height: 8,
                  ),

                  Text(
                    'Failed attempts: '
                        '$failedAttempts / '
                        '${LoginSecurityService.maxFailedAttempts}',

                    style:
                    const TextStyle(
                      color:
                      AppColors.warning,

                      fontSize: 10,
                    ),
                  ),
                ],

                const SizedBox(
                  height: 7,
                ),

                Align(
                  alignment:
                  Alignment.centerRight,

                  child: TextButton(
                    onPressed:
                    loading
                        ? null
                        : openForgotPassword,

                    child:
                    const Text(
                      'Forgot password?',

                      style:
                      TextStyle(
                        color:
                        AppColors.primary,
                      ),
                    ),
                  ),
                ),

                const SizedBox(
                  height: 12,
                ),

                // =================================================
                // SIGN IN
                // =================================================

                SizedBox(
                  width:
                  double.infinity,

                  height: 56,

                  child: ElevatedButton(
                    style:
                    ElevatedButton
                        .styleFrom(
                      backgroundColor:
                      AppColors
                          .primaryDark,

                      foregroundColor:
                      Colors.white,

                      shape:
                      RoundedRectangleBorder(
                        borderRadius:
                        BorderRadius.circular(
                          14,
                        ),
                      ),
                    ),

                    onPressed:
                    loginDisabled
                        ? null
                        : login,

                    child:
                    loading
                        ? const SizedBox(
                      width: 22,
                      height: 22,

                      child:
                      CircularProgressIndicator(
                        strokeWidth:
                        2.5,

                        color:
                        Colors.white,
                      ),
                    )
                        : blocked
                        ? Text(
                      'Blocked $blockTimeText',
                    )
                        : const Text(
                      'Sign In',

                      style:
                      TextStyle(
                        fontSize:
                        15,

                        fontWeight:
                        FontWeight
                            .bold,
                      ),
                    ),
                  ),
                ),

                const SizedBox(
                  height: 24,
                ),

                // =================================================
                // DIVIDER
                // =================================================

                const Row(
                  children: [
                    Expanded(
                      child: Divider(
                        color:
                        AppColors.border,
                      ),
                    ),

                    Padding(
                      padding:
                      EdgeInsets.symmetric(
                        horizontal: 12,
                      ),

                      child: Text(
                        'or continue with',

                        style:
                        TextStyle(
                          color:
                          AppColors
                              .textSecondary,

                          fontSize: 11,
                        ),
                      ),
                    ),

                    Expanded(
                      child: Divider(
                        color:
                        AppColors.border,
                      ),
                    ),
                  ],
                ),

                const SizedBox(
                  height: 22,
                ),

                // =================================================
                // GOOGLE
                // =================================================

                SizedBox(
                  width:
                  double.infinity,

                  height: 54,

                  child: OutlinedButton(
                    style:
                    OutlinedButton
                        .styleFrom(
                      foregroundColor:
                      Colors.white,

                      backgroundColor:
                      AppColors.surface,

                      side:
                      const BorderSide(
                        color:
                        AppColors.border,
                      ),

                      shape:
                      RoundedRectangleBorder(
                        borderRadius:
                        BorderRadius.circular(
                          13,
                        ),
                      ),
                    ),

                    onPressed:
                    loading
                        ? null
                        : googleLogin,

                    child:
                    const Row(
                      mainAxisAlignment:
                      MainAxisAlignment.center,

                      children: [
                        Text(
                          'G',

                          style:
                          TextStyle(
                            color:
                            Color(
                              0xFF4285F4,
                            ),

                            fontSize: 20,

                            fontWeight:
                            FontWeight.bold,
                          ),
                        ),

                        SizedBox(
                          width: 12,
                        ),

                        Text(
                          'Sign in with Google',

                          style:
                          TextStyle(
                            fontWeight:
                            FontWeight.w600,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),

                const SizedBox(
                  height: 26,
                ),

                // =================================================
                // PDPA
                // =================================================

                Container(
                  width:
                  double.infinity,

                  padding:
                  const EdgeInsets.all(
                    13,
                  ),

                  decoration:
                  BoxDecoration(
                    color:
                    AppColors.surface,

                    borderRadius:
                    BorderRadius.circular(
                      13,
                    ),

                    border:
                    Border.all(
                      color:
                      AppColors.border,
                    ),
                  ),

                  child:
                  const Row(
                    mainAxisAlignment:
                    MainAxisAlignment.center,

                    children: [
                      Icon(
                        Icons.shield_outlined,

                        color:
                        AppColors.primary,

                        size: 15,
                      ),

                      SizedBox(
                        width: 7,
                      ),

                      Flexible(
                        child: Text(
                          'Your data is protected under PDPA 2010',

                          textAlign:
                          TextAlign.center,

                          style:
                          TextStyle(
                            color:
                            AppColors
                                .textSecondary,

                            fontSize: 10,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),

                const SizedBox(
                  height: 26,
                ),

                // =================================================
                // REGISTER
                // =================================================

                Row(
                  mainAxisAlignment:
                  MainAxisAlignment.center,

                  children: [
                    const Text(
                      "Don't have an account? ",

                      style:
                      TextStyle(
                        color:
                        AppColors
                            .textSecondary,

                        fontSize: 13,
                      ),
                    ),

                    GestureDetector(
                      onTap:
                      loading
                          ? null
                          : openRegister,

                      child:
                      const Text(
                        'Create Account',

                        style:
                        TextStyle(
                          color:
                          AppColors.primary,

                          fontSize: 13,

                          fontWeight:
                          FontWeight.bold,
                        ),
                      ),
                    ),
                  ],
                ),

                const SizedBox(
                  height: 20,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// ================================================================
// FIELD LABEL
// ================================================================

class _FieldLabel
    extends StatelessWidget {
  final String text;

  const _FieldLabel(
      this.text,
      );

  @override
  Widget build(
      BuildContext context,
      ) {
    return Text(
      text,

      style:
      const TextStyle(
        color:
        Color(
          0xFFA9C7EF,
        ),

        fontSize: 11,

        fontWeight:
        FontWeight.w600,

        letterSpacing:
        0.4,
      ),
    );
  }
}

// ================================================================
// INPUT
// ================================================================

InputDecoration _inputDecoration({
  required String hint,
  required IconData prefixIcon,
  Widget? suffix,
}) {
  return InputDecoration(
    hintText:
    hint,

    hintStyle:
    const TextStyle(
      color:
      AppColors
          .textSecondary,
    ),

    prefixIcon:
    Icon(
      prefixIcon,

      color:
      AppColors
          .textSecondary,

      size: 19,
    ),

    suffixIcon:
    suffix,

    filled:
    true,

    fillColor:
    AppColors.surface,

    contentPadding:
    const EdgeInsets.symmetric(
      horizontal: 14,
      vertical: 16,
    ),

    enabledBorder:
    OutlineInputBorder(
      borderRadius:
      BorderRadius.circular(
        13,
      ),

      borderSide:
      const BorderSide(
        color:
        AppColors.border,
      ),
    ),

    focusedBorder:
    OutlineInputBorder(
      borderRadius:
      BorderRadius.circular(
        13,
      ),

      borderSide:
      const BorderSide(
        color:
        AppColors.primary,

        width: 1.4,
      ),
    ),

    errorBorder:
    OutlineInputBorder(
      borderRadius:
      BorderRadius.circular(
        13,
      ),

      borderSide:
      const BorderSide(
        color:
        AppColors.danger,
      ),
    ),

    focusedErrorBorder:
    OutlineInputBorder(
      borderRadius:
      BorderRadius.circular(
        13,
      ),

      borderSide:
      const BorderSide(
        color:
        AppColors.danger,
      ),
    ),
  );
}