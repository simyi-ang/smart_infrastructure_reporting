import 'dart:async';

import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../../services/auth_service.dart';
import '../admin/admin_dashboard_screen.dart';
import '../citizen/citizen_dashboard_screen.dart';
import '../worker/worker_dashboard_screen.dart';
import 'login_screen.dart';

class AuthGate extends StatefulWidget {
  const AuthGate({
    super.key,
  });

  @override
  State<AuthGate> createState() =>
      _AuthGateState();
}

class _AuthGateState
    extends State<AuthGate> {
  final AuthService authService =
  AuthService();

  StreamSubscription<AuthState>?
  authSubscription;

  int authRefreshKey = 0;

  @override
  void initState() {
    super.initState();

    // IMPORTANT:
    // Rebuild this gate whenever Supabase signs in, signs out,
    // refreshes the session, or changes the authenticated user.
    authSubscription =
        Supabase.instance.client.auth
            .onAuthStateChange
            .listen(
              (
              AuthState authState,
              ) {
            if (!mounted) {
              return;
            }

            setState(() {
              authRefreshKey++;
            });
          },
        );
  }

  @override
  void dispose() {
    authSubscription?.cancel();

    super.dispose();
  }

  @override
  Widget build(
      BuildContext context,
      ) {
    final User? user =
        authService.currentUser;

    // ==========================================================
    // NOT LOGGED IN
    // ==========================================================

    if (user == null) {
      return const LoginScreen();
    }

    // ==========================================================
    // LOGGED IN -> LOAD PROFILE + ROLE
    // ==========================================================

    return FutureBuilder(
      key: ValueKey(
        '${user.id}-$authRefreshKey',
      ),

      future:
      authService.getCurrentProfile(),

      builder:
          (
          context,
          snapshot,
          ) {
        if (snapshot.connectionState ==
            ConnectionState.waiting) {
          return const Scaffold(
            body: Center(
              child:
              CircularProgressIndicator(),
            ),
          );
        }

        if (snapshot.hasError) {
          return Scaffold(
            body: Center(
              child: Padding(
                padding:
                const EdgeInsets.all(
                  25,
                ),
                child: Column(
                  mainAxisSize:
                  MainAxisSize.min,
                  children: [
                    const Icon(
                      Icons.error_outline,
                      size: 42,
                    ),
                    const SizedBox(
                      height: 12,
                    ),
                    Text(
                      'Unable to load account.\n\n'
                          '${snapshot.error}',
                      textAlign:
                      TextAlign.center,
                    ),
                    const SizedBox(
                      height: 16,
                    ),
                    OutlinedButton.icon(
                      onPressed: () {
                        if (!mounted) {
                          return;
                        }

                        setState(() {
                          authRefreshKey++;
                        });
                      },
                      icon:
                      const Icon(
                        Icons.refresh,
                      ),
                      label:
                      const Text(
                        'Retry',
                      ),
                    ),
                  ],
                ),
              ),
            ),
          );
        }

        final profile =
            snapshot.data;

        if (profile == null) {
          return const LoginScreen();
        }

        if (!profile.isActive) {
          return Scaffold(
            body: Center(
              child: Padding(
                padding:
                const EdgeInsets.all(
                  25,
                ),
                child: Column(
                  mainAxisSize:
                  MainAxisSize.min,
                  children: [
                    const Icon(
                      Icons.block_outlined,
                      size: 42,
                    ),
                    const SizedBox(
                      height: 12,
                    ),
                    const Text(
                      'This account is currently unavailable.',
                      textAlign:
                      TextAlign.center,
                    ),
                    const SizedBox(
                      height: 16,
                    ),
                    OutlinedButton(
                      onPressed: () async {
                        try {
                          await authService.logout();
                        } catch (_) {}
                      },
                      child:
                      const Text(
                        'Return to Login',
                      ),
                    ),
                  ],
                ),
              ),
            ),
          );
        }

        // ======================================================
        // ROLE-BASED ROUTING
        // ======================================================

        switch (
        profile.role
            .trim()
            .toLowerCase()) {
          case 'admin':
            return const AdminDashboardScreen();

          case 'worker':
            return const WorkerDashboardScreen();

          case 'citizen':
            return const CitizenDashboardScreen();

          default:
            return Scaffold(
              body: Center(
                child: Padding(
                  padding:
                  const EdgeInsets.all(
                    25,
                  ),
                  child: Column(
                    mainAxisSize:
                    MainAxisSize.min,
                    children: [
                      const Icon(
                        Icons
                            .warning_amber_rounded,
                        size: 42,
                      ),
                      const SizedBox(
                        height: 12,
                      ),
                      Text(
                        'Invalid user role: '
                            '${profile.role}',
                        textAlign:
                        TextAlign.center,
                      ),
                      const SizedBox(
                        height: 16,
                      ),
                      OutlinedButton(
                        onPressed: () async {
                          try {
                            await authService.logout();
                          } catch (_) {}
                        },
                        child:
                        const Text(
                          'Return to Login',
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            );
        }
      },
    );
  }
}
