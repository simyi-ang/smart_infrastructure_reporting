import 'package:flutter/material.dart';

import '../../services/auth_service.dart';
import '../../theme/app_colors.dart';

import 'account_activity_screen.dart';

class SecurityScreen extends StatefulWidget {
  const SecurityScreen({
    super.key,
  });

  @override
  State<SecurityScreen> createState() =>
      _SecurityScreenState();
}

class _SecurityScreenState
    extends State<SecurityScreen> {
  final AuthService authService =
  AuthService();

  final GlobalKey<FormState>
  passwordFormKey =
  GlobalKey<FormState>();

  final TextEditingController
  currentPasswordController =
  TextEditingController();

  final TextEditingController
  newPasswordController =
  TextEditingController();

  final TextEditingController
  confirmPasswordController =
  TextEditingController();

  bool loading = false;

  bool hideCurrentPassword = true;

  bool hideNewPassword = true;

  bool hideConfirmPassword = true;

  late Map<String, String> sessionInfo;

  @override
  void initState() {
    super.initState();

    sessionInfo =
        authService.getSessionInfo();
  }

  @override
  void dispose() {
    currentPasswordController.dispose();

    newPasswordController.dispose();

    confirmPasswordController.dispose();

    super.dispose();
  }

  // ============================================================
  // CHANGE PASSWORD
  // ============================================================

  Future<void> changePassword() async {
    if (!(passwordFormKey.currentState
        ?.validate() ??
        false)) {
      return;
    }

    final String currentPassword =
        currentPasswordController.text;

    final String newPassword =
        newPasswordController.text;

    if (currentPassword ==
        newPassword) {
      showMessage(
        'New password must be different from your current password.',
      );

      return;
    }

    setState(() {
      loading = true;
    });

    try {
      await authService
          .changePasswordWithCurrentPassword(
        currentPassword:
        currentPassword,

        newPassword:
        newPassword,
      );

      if (!mounted) {
        return;
      }

      currentPasswordController.clear();

      newPasswordController.clear();

      confirmPasswordController.clear();

      showMessage(
        'Password changed successfully.',
      );
    } catch (e) {
      if (!mounted) {
        return;
      }

      showMessage(
        e.toString().replaceFirst(
          'Exception: ',
          '',
        ),
      );
    } finally {
      if (mounted) {
        setState(() {
          loading = false;
        });
      }
    }
  }

  // ============================================================
  // DELETE ACCOUNT
  // ============================================================

  Future<void>
  requestAccountDeletion() async {
    if (authService
        .hasEmailPasswordIdentity) {
      await _passwordDeletionDialog();

      return;
    }

    if (authService.isGoogleUser) {
      await _googleDeletionDialog();

      return;
    }

    showMessage(
      'Unable to determine your sign-in method.',
    );
  }

  // ============================================================
  // PASSWORD DELETE DIALOG
  // ============================================================

  Future<void>
  _passwordDeletionDialog() async {
    final TextEditingController
    passwordController =
    TextEditingController();

    bool obscure =
    true;

    final String? password =
    await showDialog<String>(
      context: context,

      barrierDismissible:
      false,

      builder:
          (dialogContext) {
        return StatefulBuilder(
          builder:
              (
              context,
              setDialogState,
              ) {
            return AlertDialog(
              backgroundColor:
              AppColors.surface,

              title:
              const Row(
                children: [
                  Icon(
                    Icons.warning_amber_rounded,

                    color:
                    AppColors.danger,
                  ),

                  SizedBox(
                    width: 10,
                  ),

                  Expanded(
                    child: Text(
                      'Confirm Account Deletion',
                    ),
                  ),
                ],
              ),

              content: Column(
                mainAxisSize:
                MainAxisSize.min,

                crossAxisAlignment:
                CrossAxisAlignment.start,

                children: [
                  const Text(
                    'For security, enter your current password before requesting account deletion.',
                  ),

                  const SizedBox(
                    height: 18,
                  ),

                  TextField(
                    controller:
                    passwordController,

                    obscureText:
                    obscure,

                    autofocus:
                    true,

                    decoration:
                    _securityInput(
                      hint:
                      'Current password',

                      icon:
                      Icons.lock_outline,

                      suffix:
                      IconButton(
                        onPressed: () {
                          setDialogState(
                                () {
                              obscure =
                              !obscure;
                            },
                          );
                        },

                        icon: Icon(
                          obscure
                              ? Icons
                              .visibility_outlined
                              : Icons
                              .visibility_off_outlined,
                        ),
                      ),
                    ),
                  ),

                  const SizedBox(
                    height: 12,
                  ),

                  const Text(
                    'Your account will first be marked as pending deletion. This request can then be reviewed before permanent removal.',
                    style:
                    TextStyle(
                      color:
                      AppColors.textSecondary,

                      fontSize:
                      10,

                      height:
                      1.4,
                    ),
                  ),
                ],
              ),

              actions: [
                TextButton(
                  onPressed: () {
                    Navigator.pop(
                      dialogContext,
                    );
                  },

                  child:
                  const Text(
                    'Cancel',
                  ),
                ),

                ElevatedButton(
                  style:
                  ElevatedButton
                      .styleFrom(
                    backgroundColor:
                    AppColors.danger,
                  ),

                  onPressed: () {
                    final value =
                        passwordController
                            .text;

                    if (value.isEmpty) {
                      return;
                    }

                    Navigator.pop(
                      dialogContext,
                      value,
                    );
                  },

                  child:
                  const Text(
                    'Continue',
                  ),
                ),
              ],
            );
          },
        );
      },
    );

    passwordController.dispose();

    if (password == null ||
        password.isEmpty) {
      return;
    }

    final bool? finalConfirmation =
    await _finalDeletionConfirmation();

    if (finalConfirmation != true) {
      return;
    }

    setState(() {
      loading = true;
    });

    try {
      await authService
          .requestAccountDeletionAfterPassword(
        currentPassword:
        password,
      );

      if (!mounted) {
        return;
      }

      Navigator.of(context)
          .popUntil(
            (route) =>
        route.isFirst,
      );
    } catch (e) {
      if (!mounted) {
        return;
      }

      showMessage(
        e.toString().replaceFirst(
          'Exception: ',
          '',
        ),
      );
    } finally {
      if (mounted) {
        setState(() {
          loading = false;
        });
      }
    }
  }

  // ============================================================
  // GOOGLE DELETE DIALOG
  // ============================================================

  Future<void>
  _googleDeletionDialog() async {
    final bool? reauth =
    await showDialog<bool>(
      context:
      context,

      builder:
          (dialogContext) {
        return AlertDialog(
          backgroundColor:
          AppColors.surface,

          title:
          const Row(
            children: [
              Icon(
                Icons.security,

                color:
                AppColors.primary,
              ),

              SizedBox(
                width: 10,
              ),

              Expanded(
                child: Text(
                  'Verify Google Account',
                ),
              ),
            ],
          ),

          content:
          const Text(
            'For security, Google Sign-In will open again to verify your identity before the deletion request is submitted.',
          ),

          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(
                  dialogContext,
                  false,
                );
              },

              child:
              const Text(
                'Cancel',
              ),
            ),

            ElevatedButton(
              style:
              ElevatedButton
                  .styleFrom(
                backgroundColor:
                AppColors.primaryDark,
              ),

              onPressed: () {
                Navigator.pop(
                  dialogContext,
                  true,
                );
              },

              child:
              const Text(
                'Verify with Google',
              ),
            ),
          ],
        );
      },
    );

    if (reauth != true) {
      return;
    }

    final bool? finalConfirmation =
    await _finalDeletionConfirmation();

    if (finalConfirmation != true) {
      return;
    }

    setState(() {
      loading = true;
    });

    try {
      await authService
          .requestAccountDeletionAfterGoogle();

      if (!mounted) {
        return;
      }

      Navigator.of(context)
          .popUntil(
            (route) =>
        route.isFirst,
      );
    } catch (e) {
      if (!mounted) {
        return;
      }

      showMessage(
        e.toString().replaceFirst(
          'Exception: ',
          '',
        ),
      );
    } finally {
      if (mounted) {
        setState(() {
          loading = false;
        });
      }
    }
  }

  // ============================================================
  // FINAL DELETE CONFIRMATION
  // ============================================================

  Future<bool?>
  _finalDeletionConfirmation() {
    return showDialog<bool>(
      context:
      context,

      builder:
          (dialogContext) {
        return AlertDialog(
          backgroundColor:
          AppColors.surface,

          title:
          const Text(
            'Are you sure?',
          ),

          content:
          const Text(
            'This will submit an account deletion request and sign you out.',
          ),

          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(
                  dialogContext,
                  false,
                );
              },

              child:
              const Text(
                'No, Keep Account',
              ),
            ),

            ElevatedButton(
              style:
              ElevatedButton
                  .styleFrom(
                backgroundColor:
                AppColors.danger,
              ),

              onPressed: () {
                Navigator.pop(
                  dialogContext,
                  true,
                );
              },

              child:
              const Text(
                'Yes, Request Deletion',
              ),
            ),
          ],
        );
      },
    );
  }

  // ============================================================
  // LOGOUT
  // ============================================================

  Future<void> logout() async {
    try {
      await authService.logout();

      if (!mounted) {
        return;
      }

      Navigator.of(context)
          .popUntil(
            (route) =>
        route.isFirst,
      );
    } catch (e) {
      if (!mounted) {
        return;
      }

      showMessage(
        e.toString().replaceFirst(
          'Exception: ',
          '',
        ),
      );
    }
  }

  // ============================================================
  // ACTIVITY
  // ============================================================

  void openActivity() {
    Navigator.push(
      context,

      MaterialPageRoute(
        builder: (_) =>
        const AccountActivityScreen(),
      ),
    );
  }

  // ============================================================
  // MESSAGE
  // ============================================================

  void showMessage(
      String message,
      ) {
    ScaffoldMessenger.of(context)
        .hideCurrentSnackBar();

    ScaffoldMessenger.of(context)
        .showSnackBar(
      SnackBar(
        content:
        Text(
          message,
        ),
      ),
    );
  }

  // ============================================================
  // PASSWORD VALIDATION
  // ============================================================

  String? validatePassword(
      String? value,
      ) {
    final String password =
        value ?? '';

    if (password.isEmpty) {
      return 'Password is required.';
    }

    if (password.length < 8) {
      return 'Use at least 8 characters.';
    }

    if (!RegExp(
      r'[A-Z]',
    ).hasMatch(
      password,
    )) {
      return 'Add at least one uppercase letter.';
    }

    if (!RegExp(
      r'[a-z]',
    ).hasMatch(
      password,
    )) {
      return 'Add at least one lowercase letter.';
    }

    if (!RegExp(
      r'[0-9]',
    ).hasMatch(
      password,
    )) {
      return 'Add at least one number.';
    }

    if (!RegExp(
      r'[!@#$%^&*(),.?":{}|<>]',
    ).hasMatch(
      password,
    )) {
      return 'Add at least one special character.';
    }

    return null;
  }

  // ============================================================
  // BUILD
  // ============================================================

  @override
  Widget build(
      BuildContext context,
      ) {
    final bool emailVerified =
        authService.isEmailVerified;

    final bool googleUser =
        authService.isGoogleUser;

    final bool emailPasswordUser =
        authService
            .hasEmailPasswordIdentity;

    return Scaffold(
      backgroundColor:
      AppColors.background,

      body:
      SafeArea(
        child:
        ListView(
          padding:
          const EdgeInsets.all(
            18,
          ),

          children: [
            // ================================================
            // HEADER
            // ================================================

            Row(
              children: [
                Container(
                  decoration:
                  BoxDecoration(
                    color:
                    AppColors.surface,

                    borderRadius:
                    BorderRadius.circular(
                      12,
                    ),

                    border:
                    Border.all(
                      color:
                      AppColors.border,
                    ),
                  ),

                  child:
                  IconButton(
                    onPressed:
                    loading
                        ? null
                        : () {
                      Navigator.pop(
                        context,
                      );
                    },

                    icon:
                    const Icon(
                      Icons.arrow_back,
                    ),
                  ),
                ),

                const SizedBox(
                  width:
                  12,
                ),

                const Expanded(
                  child:
                  Column(
                    crossAxisAlignment:
                    CrossAxisAlignment
                        .start,

                    children: [
                      Text(
                        'Security',

                        style:
                        TextStyle(
                          fontSize:
                          23,

                          fontWeight:
                          FontWeight
                              .bold,
                        ),
                      ),

                      Text(
                        'Protect your SmartCity account',

                        style:
                        TextStyle(
                          color:
                          AppColors
                              .textSecondary,

                          fontSize:
                          11,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),

            const SizedBox(
              height:
              20,
            ),

            // ================================================
            // SECURITY OVERVIEW
            // ================================================

            _SecurityCard(
              title:
              'Account Security',

              children: [
                _SecurityInfoRow(
                  icon:
                  Icons
                      .email_outlined,

                  title:
                  'Email Verification',

                  value:
                  emailVerified
                      ? 'Verified'
                      : 'Not Verified',

                  valueColor:
                  emailVerified
                      ? AppColors.success
                      : AppColors.warning,
                ),

                _SecurityInfoRow(
                  icon:
                  Icons.login,

                  title:
                  'Sign-In Method',

                  value:
                  authService
                      .signInMethod,
                ),

                _SecurityInfoRow(
                  icon:
                  Icons
                      .account_circle_outlined,

                  title:
                  'Google Account',

                  value:
                  googleUser
                      ? 'Connected'
                      : 'Not Connected',
                ),

                _SecurityInfoRow(
                  icon:
                  Icons
                      .shield_outlined,

                  title:
                  'Session',

                  value:
                  authService
                      .currentSession !=
                      null
                      ? 'Active'
                      : 'Inactive',

                  valueColor:
                  authService
                      .currentSession !=
                      null
                      ? AppColors.success
                      : AppColors.warning,
                ),
              ],
            ),

            const SizedBox(
              height:
              16,
            ),

            // ================================================
            // EMAIL/PASSWORD CHANGE
            // ================================================

            if (emailPasswordUser)
              _SecurityCard(
                title:
                'Change Password',

                children: [
                  Container(
                    width:
                    double.infinity,

                    padding:
                    const EdgeInsets.all(
                      11,
                    ),

                    decoration:
                    BoxDecoration(
                      color:
                      AppColors.primary
                          .withOpacity(
                        0.05,
                      ),

                      borderRadius:
                      BorderRadius.circular(
                        11,
                      ),
                    ),

                    child:
                    const Row(
                      children: [
                        Icon(
                          Icons
                              .verified_user_outlined,

                          color:
                          AppColors.primary,

                          size:
                          18,
                        ),

                        SizedBox(
                          width:
                          8,
                        ),

                        Expanded(
                          child:
                          Text(
                            'Your current password is required before a new password can be saved.',

                            style:
                            TextStyle(
                              color:
                              AppColors
                                  .textSecondary,

                              fontSize:
                              9,

                              height:
                              1.4,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),

                  const SizedBox(
                    height:
                    14,
                  ),

                  Form(
                    key:
                    passwordFormKey,

                    child:
                    Column(
                      children: [
                        TextFormField(
                          controller:
                          currentPasswordController,

                          enabled:
                          !loading,

                          obscureText:
                          hideCurrentPassword,

                          decoration:
                          _securityInput(
                            hint:
                            'Current password',

                            icon:
                            Icons
                                .lock_person_outlined,

                            suffix:
                            IconButton(
                              onPressed:
                                  () {
                                setState(
                                      () {
                                    hideCurrentPassword =
                                    !hideCurrentPassword;
                                  },
                                );
                              },

                              icon:
                              Icon(
                                hideCurrentPassword
                                    ? Icons
                                    .visibility_outlined
                                    : Icons
                                    .visibility_off_outlined,
                              ),
                            ),
                          ),

                          validator:
                              (value) {
                            if (value ==
                                null ||
                                value
                                    .isEmpty) {
                              return 'Current password is required.';
                            }

                            return null;
                          },
                        ),

                        const SizedBox(
                          height:
                          12,
                        ),

                        TextFormField(
                          controller:
                          newPasswordController,

                          enabled:
                          !loading,

                          obscureText:
                          hideNewPassword,

                          decoration:
                          _securityInput(
                            hint:
                            'New password',

                            icon:
                            Icons
                                .lock_outline,

                            suffix:
                            IconButton(
                              onPressed:
                                  () {
                                setState(
                                      () {
                                    hideNewPassword =
                                    !hideNewPassword;
                                  },
                                );
                              },

                              icon:
                              Icon(
                                hideNewPassword
                                    ? Icons
                                    .visibility_outlined
                                    : Icons
                                    .visibility_off_outlined,
                              ),
                            ),
                          ),

                          validator:
                          validatePassword,
                        ),

                        const SizedBox(
                          height:
                          12,
                        ),

                        TextFormField(
                          controller:
                          confirmPasswordController,

                          enabled:
                          !loading,

                          obscureText:
                          hideConfirmPassword,

                          decoration:
                          _securityInput(
                            hint:
                            'Confirm new password',

                            icon:
                            Icons
                                .lock_reset_outlined,

                            suffix:
                            IconButton(
                              onPressed:
                                  () {
                                setState(
                                      () {
                                    hideConfirmPassword =
                                    !hideConfirmPassword;
                                  },
                                );
                              },

                              icon:
                              Icon(
                                hideConfirmPassword
                                    ? Icons
                                    .visibility_outlined
                                    : Icons
                                    .visibility_off_outlined,
                              ),
                            ),
                          ),

                          validator:
                              (value) {
                            if (value ==
                                null ||
                                value
                                    .isEmpty) {
                              return 'Please confirm the new password.';
                            }

                            if (value !=
                                newPasswordController
                                    .text) {
                              return 'Passwords do not match.';
                            }

                            return null;
                          },
                        ),

                        const SizedBox(
                          height:
                          15,
                        ),

                        SizedBox(
                          width:
                          double.infinity,

                          height:
                          50,

                          child:
                          ElevatedButton.icon(
                            style:
                            ElevatedButton
                                .styleFrom(
                              backgroundColor:
                              AppColors
                                  .primaryDark,
                            ),

                            onPressed:
                            loading
                                ? null
                                : changePassword,

                            icon:
                            const Icon(
                              Icons
                                  .security,
                            ),

                            label:
                            const Text(
                              'Verify & Change Password',
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              )
            else
              _SecurityCard(
                title:
                'Password',

                children: const [
                  _SecurityNote(
                    icon:
                    Icons
                        .account_circle_outlined,

                    title:
                    'Google Sign-In Account',

                    message:
                    'This account uses Google Sign-In, so a separate SmartCity password is not required.',
                  ),
                ],
              ),

            const SizedBox(
              height:
              16,
            ),

            // ================================================
            // CURRENT SESSION
            // ================================================

            _SecurityCard(
              title:
              'Current Session',

              children: [
                _SecurityInfoRow(
                  icon:
                  Icons
                      .alternate_email,

                  title:
                  'Account',

                  value:
                  sessionInfo[
                  'email'] ??
                      'Unknown',
                ),

                _SecurityInfoRow(
                  icon:
                  Icons
                      .login_outlined,

                  title:
                  'Login Method',

                  value:
                  sessionInfo[
                  'sign_in_method'] ??
                      'Unknown',
                ),

                _SecurityInfoRow(
                  icon:
                  Icons
                      .verified_outlined,

                  title:
                  'Verification',

                  value:
                  sessionInfo[
                  'email_verified'] ??
                      'Unknown',
                ),
              ],
            ),

            const SizedBox(
              height:
              16,
            ),

            // ================================================
            // OPTIONS
            // ================================================

            _SecurityCard(
              title:
              'Security Options',

              children: [
                _SecurityAction(
                  icon:
                  Icons.history,

                  title:
                  'Account Activity',

                  subtitle:
                  'View recent successful logins',

                  onTap:
                  openActivity,
                ),

                _SecurityAction(
                  icon:
                  Icons.logout,

                  title:
                  'Sign Out',

                  subtitle:
                  'End the current session',

                  onTap:
                  logout,
                ),
              ],
            ),

            const SizedBox(
              height:
              16,
            ),

            // ================================================
            // DANGER
            // ================================================

            Container(
              padding:
              const EdgeInsets.all(
                15,
              ),

              decoration:
              BoxDecoration(
                color:
                AppColors.danger
                    .withOpacity(
                  0.05,
                ),

                borderRadius:
                BorderRadius.circular(
                  16,
                ),

                border:
                Border.all(
                  color:
                  AppColors.danger
                      .withOpacity(
                    0.55,
                  ),
                ),
              ),

              child:
              Column(
                crossAxisAlignment:
                CrossAxisAlignment
                    .start,

                children: [
                  const Row(
                    children: [
                      Icon(
                        Icons
                            .warning_amber_rounded,

                        color:
                        AppColors.danger,
                      ),

                      SizedBox(
                        width:
                        8,
                      ),

                      Text(
                        'Danger Zone',

                        style:
                        TextStyle(
                          color:
                          AppColors.danger,

                          fontWeight:
                          FontWeight.bold,

                          fontSize:
                          14,
                        ),
                      ),
                    ],
                  ),

                  const SizedBox(
                    height:
                    9,
                  ),

                  Text(
                    emailPasswordUser
                        ? 'Your current password will be required before an account deletion request can be submitted.'
                        : 'Google verification will be required before an account deletion request can be submitted.',

                    style:
                    const TextStyle(
                      color:
                      AppColors
                          .textSecondary,

                      fontSize:
                      10,

                      height:
                      1.4,
                    ),
                  ),

                  const SizedBox(
                    height:
                    14,
                  ),

                  SizedBox(
                    width:
                    double.infinity,

                    child:
                    OutlinedButton.icon(
                      style:
                      OutlinedButton
                          .styleFrom(
                        side:
                        const BorderSide(
                          color:
                          AppColors
                              .danger,
                        ),
                      ),

                      onPressed:
                      loading
                          ? null
                          : requestAccountDeletion,

                      icon:
                      const Icon(
                        Icons
                            .delete_forever_outlined,

                        color:
                        AppColors.danger,
                      ),

                      label:
                      const Text(
                        'Request Account Deletion',

                        style:
                        TextStyle(
                          color:
                          AppColors.danger,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),

            const SizedBox(
              height:
              30,
            ),
          ],
        ),
      ),
    );
  }
}

// ================================================================
// CARD
// ================================================================

class _SecurityCard
    extends StatelessWidget {
  final String title;

  final List<Widget> children;

  const _SecurityCard({
    required this.title,
    required this.children,
  });

  @override
  Widget build(
      BuildContext context,
      ) {
    return Container(
      padding:
      const EdgeInsets.all(
        15,
      ),

      decoration:
      BoxDecoration(
        color:
        AppColors.surface,

        borderRadius:
        BorderRadius.circular(
          16,
        ),

        border:
        Border.all(
          color:
          AppColors.border,
        ),
      ),

      child:
      Column(
        crossAxisAlignment:
        CrossAxisAlignment.start,

        children: [
          Text(
            title,

            style:
            const TextStyle(
              fontSize:
              14,

              fontWeight:
              FontWeight.bold,
            ),
          ),

          const SizedBox(
            height:
            12,
          ),

          ...children,
        ],
      ),
    );
  }
}

// ================================================================
// INFO
// ================================================================

class _SecurityInfoRow
    extends StatelessWidget {
  final IconData icon;

  final String title;

  final String value;

  final Color? valueColor;

  const _SecurityInfoRow({
    required this.icon,
    required this.title,
    required this.value,
    this.valueColor,
  });

  @override
  Widget build(
      BuildContext context,
      ) {
    return Padding(
      padding:
      const EdgeInsets.symmetric(
        vertical:
        8,
      ),

      child:
      Row(
        children: [
          Icon(
            icon,

            color:
            AppColors.primary,

            size:
            20,
          ),

          const SizedBox(
            width:
            11,
          ),

          Expanded(
            child:
            Text(
              title,

              style:
              const TextStyle(
                color:
                AppColors
                    .textSecondary,

                fontSize:
                11,
              ),
            ),
          ),

          Flexible(
            child:
            Text(
              value,

              textAlign:
              TextAlign.right,

              style:
              TextStyle(
                color:
                valueColor ??
                    Colors.white,

                fontSize:
                11,

                fontWeight:
                FontWeight.w600,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ================================================================
// ACTION
// ================================================================

class _SecurityAction
    extends StatelessWidget {
  final IconData icon;

  final String title;

  final String subtitle;

  final VoidCallback onTap;

  const _SecurityAction({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.onTap,
  });

  @override
  Widget build(
      BuildContext context,
      ) {
    return ListTile(
      contentPadding:
      EdgeInsets.zero,

      leading:
      Icon(
        icon,

        color:
        AppColors.primary,
      ),

      title:
      Text(
        title,

        style:
        const TextStyle(
          fontSize:
          12,

          fontWeight:
          FontWeight.bold,
        ),
      ),

      subtitle:
      Text(
        subtitle,

        style:
        const TextStyle(
          color:
          AppColors
              .textSecondary,

          fontSize:
          9,
        ),
      ),

      trailing:
      const Icon(
        Icons.chevron_right,

        color:
        AppColors
            .textSecondary,
      ),

      onTap:
      onTap,
    );
  }
}

// ================================================================
// NOTE
// ================================================================

class _SecurityNote
    extends StatelessWidget {
  final IconData icon;

  final String title;

  final String message;

  const _SecurityNote({
    required this.icon,
    required this.title,
    required this.message,
  });

  @override
  Widget build(
      BuildContext context,
      ) {
    return Container(
      padding:
      const EdgeInsets.all(
        12,
      ),

      decoration:
      BoxDecoration(
        color:
        AppColors.primary
            .withOpacity(
          0.06,
        ),

        borderRadius:
        BorderRadius.circular(
          12,
        ),

        border:
        Border.all(
          color:
          AppColors.primaryDark,
        ),
      ),

      child:
      Row(
        crossAxisAlignment:
        CrossAxisAlignment.start,

        children: [
          Icon(
            icon,

            color:
            AppColors.primary,
          ),

          const SizedBox(
            width:
            10,
          ),

          Expanded(
            child:
            Column(
              crossAxisAlignment:
              CrossAxisAlignment.start,

              children: [
                Text(
                  title,

                  style:
                  const TextStyle(
                    fontWeight:
                    FontWeight.bold,

                    fontSize:
                    11,
                  ),
                ),

                const SizedBox(
                  height:
                  4,
                ),

                Text(
                  message,

                  style:
                  const TextStyle(
                    color:
                    AppColors
                        .textSecondary,

                    fontSize:
                    10,

                    height:
                    1.4,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// ================================================================
// INPUT
// ================================================================

InputDecoration _securityInput({
  required String hint,
  required IconData icon,
  Widget? suffix,
}) {
  return InputDecoration(
    hintText:
    hint,

    prefixIcon:
    Icon(
      icon,

      color:
      AppColors.textSecondary,
    ),

    suffixIcon:
    suffix,

    filled:
    true,

    fillColor:
    AppColors.background,

    enabledBorder:
    OutlineInputBorder(
      borderRadius:
      BorderRadius.circular(
        13,
      ),

      borderSide:
      const BorderSide(
        color:
        AppColors.border,
      ),
    ),

    focusedBorder:
    OutlineInputBorder(
      borderRadius:
      BorderRadius.circular(
        13,
      ),

      borderSide:
      const BorderSide(
        color:
        AppColors.primary,
      ),
    ),

    errorBorder:
    OutlineInputBorder(
      borderRadius:
      BorderRadius.circular(
        13,
      ),

      borderSide:
      const BorderSide(
        color:
        AppColors.danger,
      ),
    ),

    focusedErrorBorder:
    OutlineInputBorder(
      borderRadius:
      BorderRadius.circular(
        13,
      ),

      borderSide:
      const BorderSide(
        color:
        AppColors.danger,
      ),
    ),
  );
}