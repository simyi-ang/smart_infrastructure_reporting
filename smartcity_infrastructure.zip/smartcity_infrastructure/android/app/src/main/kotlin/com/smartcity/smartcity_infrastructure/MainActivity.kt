package com.smartcity.smartcity_infrastructure

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
